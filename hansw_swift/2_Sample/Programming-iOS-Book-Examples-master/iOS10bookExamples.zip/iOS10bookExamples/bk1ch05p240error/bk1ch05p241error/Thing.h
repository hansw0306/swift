

#import <Foundation/Foundation.h>

@interface Thing : NSObject

@end
