//
//  MyCoolModule.h
//  MyCoolModule
//
//  Created by Matt Neuburg on 8/17/16.
//  Copyright © 2016 Matt Neuburg. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyCoolModule.
FOUNDATION_EXPORT double MyCoolModuleVersionNumber;

//! Project version string for MyCoolModule.
FOUNDATION_EXPORT const unsigned char MyCoolModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyCoolModule/PublicHeader.h>


