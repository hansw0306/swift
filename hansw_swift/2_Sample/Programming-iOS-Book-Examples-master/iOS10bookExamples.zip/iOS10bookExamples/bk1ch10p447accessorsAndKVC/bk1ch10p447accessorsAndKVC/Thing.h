

#import <UIKit/UIKit.h>

@interface Thing : NSObject
- (void) test;
- (void) test2;
- (void) test3;
@end
