import UIKit

@UIApplicationMain
class AppDelegate : UIResponder, UIApplicationDelegate {
    var window : UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey : Any]?) -> Bool {
        
//        let arr = CIFilter.filterNamesInCategories(nil)
//        print(CIFilter(name:arr[0])!.attributes)
        
        return true
    }
}
