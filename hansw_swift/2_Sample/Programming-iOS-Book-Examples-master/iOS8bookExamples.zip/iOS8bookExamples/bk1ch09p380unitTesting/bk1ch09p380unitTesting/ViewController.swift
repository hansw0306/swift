

import UIKit

public class ViewController: UIViewController {

    public func dogMyCats(s:String) -> String {
        return "dogs"
    }



}

