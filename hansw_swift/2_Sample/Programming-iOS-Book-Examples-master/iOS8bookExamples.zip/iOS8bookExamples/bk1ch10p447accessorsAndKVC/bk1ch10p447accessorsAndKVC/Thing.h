

#import <UIKit/UIKit.h>

@interface Thing : NSObject
- (void) test;
@end
