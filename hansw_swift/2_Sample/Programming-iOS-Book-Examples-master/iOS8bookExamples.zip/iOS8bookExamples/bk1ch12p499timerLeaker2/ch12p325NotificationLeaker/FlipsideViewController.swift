

import UIKit

protocol FlipsideViewControllerDelegate : class {
    func flipsideViewControllerDidFinish(controller:FlipsideViewController)
}

class FlipsideViewController: UIViewController {
    
    weak var delegate : FlipsideViewControllerDelegate! = nil
    
    var timer : CancelableTimer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        println("creating timer")
        self.timer = CancelableTimer(once: false) {
            [unowned self] in // comment out this line to leak
            self.dummy()
        }
        println("starting timer")
        self.timer.startWithInterval(1)
    }
    
    func dummy() {
        println("timer fired")
    }
    
    @IBAction func done (sender:AnyObject!) {
        println("done")
        self.delegate?.flipsideViewControllerDidFinish(self)
    }
    
    // if deinit is not called when you tap Done, we are leaking
    deinit {
        println("deinit")
        self.timer?.cancel()
    }
    
}

extension FlipsideViewController : UIBarPositioningDelegate {
    func positionForBar(bar: UIBarPositioning) -> UIBarPosition {
        return .TopAttached
    }
}
