
import UIKit

class MyView: UIView {

}
