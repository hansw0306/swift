

#import <Foundation/Foundation.h>

@interface PatternHelper : NSObject
- (CGPatternRef) patternMaker;
@end
