import UIKit

class Data{
    var main:String
    var px:String
    var py:String
    
    init(main: String, px:String, py:String) {
        self.main = main
        self.px = px
        self.py = py
    }
}

//enum detailtype:String {
//    case A = "A"
//    case B = "B"
//}
